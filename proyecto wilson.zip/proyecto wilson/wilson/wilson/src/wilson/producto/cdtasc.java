/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package wilson.producto;

import wilson.producto.string;

/**
 *
 * @author RPR-C80A404ES
 */
public class cdtasc {
    private int id_cdtsasc;
    private int id_aven;
    private int id_call;
    private int id_cross;
    private int id_dep;
    private int id_scoot;
    private int id_turi;
    

    public int getId_cdtsasc() {
        return id_cdtsasc;
    }

    public int getId_aven() {
        return id_aven;
    }

    public int getId_call() {
        return id_call;
    }

    public int getId_cross() {
        return id_cross;
    }

    public int getId_dep() {
        return id_dep;
    }

    public int getId_scoot() {
        return id_scoot;
    }

    public int getId_turi() {
        return id_turi;
    }

    public void setId_cdtsasc(int id_cdtsasc) {
        this.id_cdtsasc = id_cdtsasc;
    }

    public void setId_aven(int id_aven) {
        this.id_aven = id_aven;
    }

    public void setId_call(int id_call) {
        this.id_call = id_call;
    }

    public void setId_cross(int id_cross) {
        this.id_cross = id_cross;
    }

    public void setId_dep(int id_dep) {
        this.id_dep = id_dep;
    }

    public void setId_scoot(int id_scoot) {
        this.id_scoot = id_scoot;
    }

    public void setId_turi(int id_turi) {
        this.id_turi = id_turi;
    }

    public cdtasc(int id_cdtsasc, int id_aven, int id_call, int id_cross, int id_dep, int id_scoot, int id_turi) {
        this.id_cdtsasc = id_cdtsasc;
        this.id_aven = id_aven;
        this.id_call = id_call;
        this.id_cross = id_cross;
        this.id_dep = id_dep;
        this.id_scoot = id_scoot;
        this.id_turi = id_turi;
    }

    public String tablas() {
        return "cdtasc{" + "id_cdtsasc=" + id_cdtsasc + ", id_aven=" + id_aven + ", id_call=" + id_call + ", id_cross=" + id_cross + ", id_dep=" + id_dep + ", id_scoot=" + id_scoot + ", id_turi=" + id_turi + '}';
    }


}
