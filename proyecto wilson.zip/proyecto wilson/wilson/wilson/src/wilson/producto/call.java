/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wilson.producto;

/**
 *
 * @author pirat
 */
public class call {
    private int id_call;
   private String marca; 
   private String color;
   private String precio;

    public int getId_call() {
        return id_call;
    }

    public String getMarca() {
        return marca;
    }

    public String getColor() {
        return color;
    }

    public String getPrecio() {
        return precio;
    }

    public void setId_call(int id_call) {
        this.id_call = id_call;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public call(int id_call, String marca, String color, String precio) {
        this.id_call = id_call;
        this.marca = marca;
        this.color = color;
        this.precio = precio;
    }

    public String tablascall() {
        return "call{" + "id_call=" + id_call + ", marca=" + marca + ", color=" + color + ", precio=" + precio + '}';
    }
   
}
