/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wilson.producto;


class string {
    private string nombre;
    private string codigo;
    private string modulo;

    public string(string nombre, string codigo, string modulo) {
        this.nombre = nombre;
        this.codigo = codigo;
        this.modulo = modulo;
        
        
    }

    public string getNombre() {
        return nombre;
    }

    public string getCodigo() {
        return codigo;
    }

    public string getModulo() {
        return modulo;
        
        
    }

    public String mostradatos() {
        return "string{" + "nombre=" + nombre + ", codigo=" + codigo + ", modulo=" + modulo + '}';
    }
    
    

}
