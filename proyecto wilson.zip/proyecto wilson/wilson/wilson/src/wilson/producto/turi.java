/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wilson.producto;

/**
 *
 * @author pirat
 */
public class turi {
    private int id_turi;
   private String marca; 
   private String color;
   private String precio;

    public int getId_turi() {
        return id_turi;
    }

    public String getMarca() {
        return marca;
    }

    public String getColor() {
        return color;
    }

    public String getPrecio() {
        return precio;
    }

    public void setId_turi(int id_turi) {
        this.id_turi = id_turi;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public turi(int id_turi, String marca, String color, String precio) {
        this.id_turi = id_turi;
        this.marca = marca;
        this.color = color;
        this.precio = precio;
    }

    
    public String tablas_turi() {
        return "turi{" + "id_turi=" + id_turi + ", marca=" + marca + ", color=" + color + ", precio=" + precio + '}';
    }
    
   
}
