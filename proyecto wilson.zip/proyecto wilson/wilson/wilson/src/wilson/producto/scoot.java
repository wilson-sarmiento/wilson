/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wilson.producto;

/**
 *
 * @author pirat
 */
public class scoot {
    private int id_scoot;
   private String marca; 
   private String color;
   private String precio;

    public int getId_scoot() {
        return id_scoot;
    }

    public String getMarca() {
        return marca;
    }

    public String getColor() {
        return color;
    }

    public String getPrecio() {
        return precio;
    }

    public void setId_scoot(int id_scoot) {
        this.id_scoot = id_scoot;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public scoot(int id_scoot, String marca, String color, String precio) {
        this.id_scoot = id_scoot;
        this.marca = marca;
        this.color = color;
        this.precio = precio;
    }

   
    public String tablasscoot() {
        return "scoot{" + "id_scoot=" + id_scoot + ", marca=" + marca + ", color=" + color + ", precio=" + precio + '}';
    }
    
}
