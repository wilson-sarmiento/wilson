/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wilson.producto;

/**
 *
 * @author pirat
 */
public class cross {
    private int id_cross;
   private String marca; 
   private String color;
   private String precio;

    public int getId_cross() {
        return id_cross;
    }

    public String getMarca() {
        return marca;
    }

    public String getColor() {
        return color;
    }

    public String getPrecio() {
        return precio;
    }

    public void setId_cross(int id_cross) {
        this.id_cross = id_cross;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public cross(int id_cross, String marca, String color, String precio) {
        this.id_cross = id_cross;
        this.marca = marca;
        this.color = color;
        this.precio = precio;
    }

 
    public String tablascross() {
        return "cross{" + "id_cross=" + id_cross + ", marca=" + marca + ", color=" + color + ", precio=" + precio + '}';
    }
   
   
    
}
