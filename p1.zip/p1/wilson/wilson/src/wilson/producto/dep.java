/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wilson.producto;

/**
 *
 * @author pirat
 */
public class dep {
    private int id_dep;
   private String marca; 
   private String color;
   private String precio;

    public int getId_dep() {
        return id_dep;
    }

    public String getMarca() {
        return marca;
    }

    public String getColor() {
        return color;
    }

    public String getPrecio() {
        return precio;
    }

    public void setId_dep(int id_dep) {
        this.id_dep = id_dep;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public dep(int id_dep, String marca, String color, String precio) {
        this.id_dep = id_dep;
        this.marca = marca;
        this.color = color;
        this.precio = precio;
    }


    public String tablasdep() {
        return "dep{" + "id_dep=" + id_dep + ", marca=" + marca + ", color=" + color + ", precio=" + precio + '}';
    }
   
    
}
