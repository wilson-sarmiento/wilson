/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wilson.producto;

/**
 *
 * @author pirat
 */
public class aven {
   private int id_aven;
   private String marca; 
   private String color;
   private String precio;

    public int getId_aven() {
        return id_aven;
    }

    public String getMarca() {
        return marca;
    }

    public String getColor() {
        return color;
    }

    public String getPrecio() {
        return precio;
    }

    public void setId_aven(int id_aven) {
        this.id_aven = id_aven;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public aven(int id_aven, String marca, String color, String precio) {
        this.id_aven = id_aven;
        this.marca = marca;
        this.color = color;
        this.precio = precio;
    }

    public String aven() {
        return "aven{" + "id_aven=" + id_aven + ", marca=" + marca + ", color=" + color + ", precio=" + precio + '}';
    }
   
}
