/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inventarios;

/**
 *
 * @author pirat
 */
public class inv_dep {
    
    private int id_inv_dep;
private String Ducati_Panigale_V4;
private String Yamaha_YZF_R1M;
private String Kawasaki_Ninja_H2;

    public int getId_inv_dep() {
        return id_inv_dep;
    }

    public String getDucati_Panigale_V4() {
        return Ducati_Panigale_V4;
    }

    public String getYamaha_YZF_R1M() {
        return Yamaha_YZF_R1M;
    }

    public String getKawasaki_Ninja_H2() {
        return Kawasaki_Ninja_H2;
    }

    public void setId_inv_dep(int id_inv_dep) {
        this.id_inv_dep = id_inv_dep;
    }

    public void setDucati_Panigale_V4(String Ducati_Panigale_V4) {
        this.Ducati_Panigale_V4 = Ducati_Panigale_V4;
    }

    public void setYamaha_YZF_R1M(String Yamaha_YZF_R1M) {
        this.Yamaha_YZF_R1M = Yamaha_YZF_R1M;
    }

    public void setKawasaki_Ninja_H2(String Kawasaki_Ninja_H2) {
        this.Kawasaki_Ninja_H2 = Kawasaki_Ninja_H2;
    }

    public inv_dep(int id_inv_dep, String Ducati_Panigale_V4, String Yamaha_YZF_R1M, String Kawasaki_Ninja_H2) {
        this.id_inv_dep = id_inv_dep;
        this.Ducati_Panigale_V4 = Ducati_Panigale_V4;
        this.Yamaha_YZF_R1M = Yamaha_YZF_R1M;
        this.Kawasaki_Ninja_H2 = Kawasaki_Ninja_H2;
    }

    
    public String inv_dep() {
        return "inv_dep{" + "id_inv_dep=" + id_inv_dep + ", Ducati_Panigale_V4=" + Ducati_Panigale_V4 + ", Yamaha_YZF_R1M=" + Yamaha_YZF_R1M + ", Kawasaki_Ninja_H2=" + Kawasaki_Ninja_H2 + '}';
    }


    
    
}
