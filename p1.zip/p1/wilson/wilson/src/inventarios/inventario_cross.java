/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inventarios;

/**
 *
 * @author pirat
 */
public class inventario_cross {
    private int id_cross;
private String Beta_RX450;
private String Husqvarna_FC450;
private String GasGas_MC450F;

    public int getId_cross() {
        return id_cross;
    }

    public String getBeta_RX450() {
        return Beta_RX450;
    }

    public String getHusqvarna_FC450() {
        return Husqvarna_FC450;
    }

    public String getGasGas_MC450F() {
        return GasGas_MC450F;
    }

    public void setId_cross(int id_cross) {
        this.id_cross = id_cross;
    }

    public void setBeta_RX450(String Beta_RX450) {
        this.Beta_RX450 = Beta_RX450;
    }

    public void setHusqvarna_FC450(String Husqvarna_FC450) {
        this.Husqvarna_FC450 = Husqvarna_FC450;
    }

    public void setGasGas_MC450F(String GasGas_MC450F) {
        this.GasGas_MC450F = GasGas_MC450F;
    }

    public inventario_cross(int id_cross, String Beta_RX450, String Husqvarna_FC450, String GasGas_MC450F) {
        this.id_cross = id_cross;
        this.Beta_RX450 = Beta_RX450;
        this.Husqvarna_FC450 = Husqvarna_FC450;
        this.GasGas_MC450F = GasGas_MC450F;
    }

    
    public String inv_croos() {
        return "inventario_cross{" + "id_cross=" + id_cross + ", Beta_RX450=" + Beta_RX450 + ", Husqvarna_FC450=" + Husqvarna_FC450 + ", GasGas_MC450F=" + GasGas_MC450F + '}';
    }


    
}
