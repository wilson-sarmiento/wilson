/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inventarios;

/**
 *
 * @author pirat
 */
public class inventarios_call {
    private int id_call;
private String Honda_CBR1000RR;
private String Yamaha_YZF_R1;
private String Kawasaki_Ninja_400;

    public int getId_call() {
        return id_call;
    }

    public String getHonda_CBR1000RR() {
        return Honda_CBR1000RR;
    }

    public String getYamaha_YZF_R1() {
        return Yamaha_YZF_R1;
    }

    public String getKawasaki_Ninja_400() {
        return Kawasaki_Ninja_400;
    }

    public void setId_call(int id_call) {
        this.id_call = id_call;
    }

    public void setHonda_CBR1000RR(String Honda_CBR1000RR) {
        this.Honda_CBR1000RR = Honda_CBR1000RR;
    }

    public void setYamaha_YZF_R1(String Yamaha_YZF_R1) {
        this.Yamaha_YZF_R1 = Yamaha_YZF_R1;
    }

    public void setKawasaki_Ninja_400(String Kawasaki_Ninja_400) {
        this.Kawasaki_Ninja_400 = Kawasaki_Ninja_400;
    }

    public inventarios_call(int id_call, String Honda_CBR1000RR, String Yamaha_YZF_R1, String Kawasaki_Ninja_400) {
        this.id_call = id_call;
        this.Honda_CBR1000RR = Honda_CBR1000RR;
        this.Yamaha_YZF_R1 = Yamaha_YZF_R1;
        this.Kawasaki_Ninja_400 = Kawasaki_Ninja_400;
    }

    public String inventarios_calle() {
        return "inventarios_call{" + "id_call=" + id_call + ", Honda_CBR1000RR=" + Honda_CBR1000RR + ", Yamaha_YZF_R1=" + Yamaha_YZF_R1 + ", Kawasaki_Ninja_400=" + Kawasaki_Ninja_400 + '}';
    }


    
}
