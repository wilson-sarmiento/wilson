/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inventarios;

/**
 *
 * @author pirat
 */
public class inventarios_aven {
    private int id_aven;
    private String Honda_Africa_Twin;
    private String BMW_R_1250_GS;
    private String Yamaha_Ténéré_700;

    public int getId_aven() {
        return id_aven;
    }

    public String getHonda_Africa_Twin() {
        return Honda_Africa_Twin;
    }

    public String getBMW_R_1250_GS() {
        return BMW_R_1250_GS;
    }

    public String getYamaha_Ténéré_700() {
        return Yamaha_Ténéré_700;
    }

    public void setId_aven(int id_aven) {
        this.id_aven = id_aven;
    }

    public void setHonda_Africa_Twin(String Honda_Africa_Twin) {
        this.Honda_Africa_Twin = Honda_Africa_Twin;
    }

    public void setBMW_R_1250_GS(String BMW_R_1250_GS) {
        this.BMW_R_1250_GS = BMW_R_1250_GS;
    }

    public void setYamaha_Ténéré_700(String Yamaha_Ténéré_700) {
        this.Yamaha_Ténéré_700 = Yamaha_Ténéré_700;
    }

    public inventarios_aven(int id_aven, String Honda_Africa_Twin, String BMW_R_1250_GS, String Yamaha_Ténéré_700) {
        this.id_aven = id_aven;
        this.Honda_Africa_Twin = Honda_Africa_Twin;
        this.BMW_R_1250_GS = BMW_R_1250_GS;
        this.Yamaha_Ténéré_700 = Yamaha_Ténéré_700;
    }

  
    public String inventarios_aven() {
        return "inventarios_aven{" + "id_aven=" + id_aven + ", Honda_Africa_Twin=" + Honda_Africa_Twin + ", BMW_R_1250_GS=" + BMW_R_1250_GS + ", Yamaha_T\u00e9n\u00e9r\u00e9_700=" + Yamaha_Ténéré_700 + '}';
    }
    
    
    

}
